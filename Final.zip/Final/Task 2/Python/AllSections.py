# Convenience file for quickly importing all of the sections
from PersonalSection import *
from AddressSection import *
from ClothingSection import *
from TransportSection import *
from DonationSection import *
from CompletionSection import *